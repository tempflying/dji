package com.tju.fly.WayPoint;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import com.tju.fly.WayPoint.Point;

public class Draw extends View {
	 private Paint paint;//声明画笔
	 private List<Point> pointList = new ArrayList<Point>();
	 
	 public Draw(Context context, AttributeSet attrs) {
		 super(context, attrs);
		 paint = new Paint();
		 paint.setColor(Color.BLACK);
		 setWillNotDraw(false);
	 }
	 
	 @Override  
     protected void onDraw(Canvas canvas) { 
		 super.onDraw(canvas); 
		 
		 paint.setColor(Color.BLACK);
        for(int i = 0; i < pointList.size()-1;i++){
        	canvas.drawLine(pointList.get(i).x, pointList.get(i).y,
					pointList.get(i+1).x, pointList.get(i+1).y, paint);
        } 
/*        
        canvas.drawLine(10, 10, 80, 80, paint);
        canvas.drawLine(98.0f, 185.0f, 291.0f, 99.0f, paint);*/
        
        invalidate();
	 }
	 
	 public void addPoint(Point p){
         pointList.add(p);
	 }
	 
	 public List<Point> getPoints(){
		 return pointList;
	 }

    public List<Point> getSendPoints(){
        List<Point> sendList = new ArrayList<Point>();
        for(int i = 1; i < pointList.size() && i < 22; i ++){    // 这里设置了最多发送的点数
            Point p1 = pointList.get(i - 1);
            Point p2 = pointList.get(i);
            sendList.add(new Point((p2.x - p1.x) / 50, (p2.y-p1.y)/ 50));
        }
        return sendList;
    }

	public void clearPoints(){
		pointList.clear();
	}
}
