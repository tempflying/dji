package com.tju.fly.BaseWork;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.tju.fly.R;
import com.tju.fly.WayPoint.WayPointActivity;

import dji.sdk.Products.DJIAircraft;
import dji.sdk.base.DJIBaseProduct;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化界面和界面的点击事件
        initUIAndCallback();

        // 初始化DJI的回调函数,比如拍照录像,控制飞行的回调函数
        initDJICallback();

        // 初始化DJI的实例对象,并用上面定义的回调函数初始化下面的例子,因为设备连接变更时会调用这个函数
        // 而不必重新初始化callback,所以这里把初始化回调和初始化DJI实例分离。
        initDJIObject();

        // 初始化对 设备连接变更时 对广播的处理函数
        initBoardCastFilter();
    }

    /********************************************************************************************************************************/

    TextView mConnectStatusTextView;
    TextView debuggerView;
    Button wayPointButton;
    // 初始化界面和界面的点击事件
    private void initUIAndCallback() {
        mConnectStatusTextView = (TextView)findViewById(R.id.connectionState);
        debuggerView = (TextView)findViewById(R.id.debugerView);
        wayPointButton = (Button)findViewById(R.id.WayPointButton);

        if (wayPointButton != null) {
            wayPointButton.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.WayPointButton){
            ComponentName comp = new ComponentName(MainActivity.this, WayPointActivity.class);
            Intent intent = new Intent();
            intent.setComponent(comp);
            startActivity(intent);
        }
    }

    /*******************************************************************************************************************************/

    // 初始化DJI的回调函数,比如拍照录像,控制飞行的回调函数
    private void initDJICallback() {
    }

    // 初始化DJI的实例对象,并用上面定义的回调函数初始化下面的例子,因为设备连接变更时会调用这个函数
    // 而不必重新初始化callback,所以这里把初始化回调和初始化DJI实例分离。
    private void initDJIObject() {
    }

    /********************************************************************************************************************************/

    /** 这部分监视连接状态的功能一般不会改变 */
    private void initBoardCastFilter() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(OurDJIApplication.FLAG_CONNECTION_CHANGE);
        registerReceiver(broadcastReceiver, filter);
    }

    // 接受到连接或产品变更的广播后的处理函数
    protected BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateTitleBar();
            onProductChange();
        }
    };

    // 显示连接情况的函数 以 变更时的处理函数（重新初始化图像显示窗口）
    private void updateTitleBar() {
        if(mConnectStatusTextView == null) return;
        boolean ret = false;
        DJIBaseProduct product = OurDJIApplication.getProductInstance();
        if(product != null){
            if(product.isConnected()){ // DJIBaseProduct
                mConnectStatusTextView.setText(OurDJIApplication.getProductInstance().getModel().toString() + " Connected");
                ret = true;
            }
            else if(product instanceof DJIAircraft){ // DJIAircraft
                DJIAircraft aircraft = (DJIAircraft)product;
                if(aircraft.getRemoteController() != null && aircraft.getRemoteController().isConnected()){
                    mConnectStatusTextView.setText("Only RC Connected");
                    ret = true;
                }
            }
        }

        if(!ret){
            mConnectStatusTextView.setText("DisConnected");
        }
    }

    private void onProductChange() {
        initDJIObject();
    }

    public void print(final String msg){
//        runOnUiThread(new Runnable() {
//            public void run() {
//                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
//            }
//        });
        if(debuggerView != null){
            debuggerView.setText(debuggerView.getText() + "\n" + msg);
        }else{
            toast("debug view is none");
        }
    }

    public void toast(final String msg){
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
