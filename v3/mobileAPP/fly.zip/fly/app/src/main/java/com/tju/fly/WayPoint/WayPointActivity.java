package com.tju.fly.WayPoint;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tju.fly.BaseWork.OurDJIApplication;
import com.tju.fly.R;
import com.tju.fly.Tool.OurArrayByteConvertUtil;
import com.tju.fly.Tool.OurByteConvertUtil;

import java.util.Arrays;
import java.util.List;

import dji.sdk.FlightController.DJIFlightController;
import dji.sdk.FlightController.DJIFlightControllerDelegate;
import dji.sdk.Products.DJIAircraft;
import dji.sdk.base.DJIBaseComponent;
import dji.sdk.base.DJIBaseProduct;
import dji.sdk.base.DJIError;

public class WayPointActivity extends AppCompatActivity implements View.OnClickListener{

    // 前台UI部分
    private TextView eventlable;
    private TextView histroy;
    private TextView TouchView;
    private Draw draw;
    //存放各个位置的坐标
    private Button myButton;
    private Button flyButton;
    private SeekBar seekBar;

    void UIOnCreate(){
        draw = (Draw) findViewById(R.id.touch_area);
        /*histroy = (TextView) findViewById(R.id.history_label);*/
        eventlable = (TextView) findViewById(R.id.event_label);

        myButton = (Button)findViewById(R.id.clear_button);
        flyButton = (Button)findViewById(R.id.fly_button);
        seekBar = (SeekBar)findViewById(R.id.bar);

        //设置比例尺滑动条的监听函数
        seekBar.setMax(100);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
                //监听结束滑动时的
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
                //监听开始滑动时的
            }

            public void onProgressChanged(SeekBar seekBar, int progress, boolean arg2) {
                // TODO Auto-generated method stub
                String msg = "";
                msg = "比例尺为 " + "1 : " + progress;
                eventlable.setText(msg);
            }
        });
        //重新画按钮的监听函数
        myButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                draw.getPoints().clear();
            }
        });

        //传送飞行路线按钮的监听函数
        flyButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(draw.getPoints().size() >  1) {
                    List<Point> sendPoints = draw.getSendPoints();
                    sendDataToOnBoard(getBytes(sendPoints));
                    //draw.clearPoints();
                    print("send data size:" + sendPoints.size());
                    for(int i = 0; i < sendPoints.size(); i++) {
                        print(sendPoints.get(i).x + " " + sendPoints.get(i).y + "\n");
                    }
                }
            }
        });

        draw.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    // 当按下的时候
                    case (MotionEvent.ACTION_DOWN):
                        Display("ACTION_DOWN", event);
                        break;
                    // 当按上的时候
                    case (MotionEvent.ACTION_UP):
                    /*int historysize = ProcessHistory(event);
                    histroy.setText("历史数据" + historysize);   */
                        Display("ACTION_UP", event);
                        break;
                    // 当触摸的时候
                    case (MotionEvent.ACTION_MOVE):
                        Display("ACTION_MOVE", event);
                }
                return true;
            }

        });
    }

    public byte[] getBytes(List<Point> points){
        byte[] data = new byte[points.size() * 2 * 4];
        for(int i = 0; i < points.size(); i++){
            byte[] temp = OurByteConvertUtil.getBytes(points.get(i).x);
            System.arraycopy(temp, 0, data, 8 * i, 4);
            temp = OurByteConvertUtil.getBytes(points.get(i).y);
            System.arraycopy(temp, 0, data, 8 * i + 4, 4);
        }
        return data;
    }

    //返回两点之间的距离
    public float distance(float x, float y, float c, float d){
        float result;
        result = (float) Math.sqrt(Math.pow((x-c), 2)+Math.pow((y-d), 2));
        return result;
    }
    public void Display(String eventType, MotionEvent event) {
        // 触点相对坐标的信息
        float x = (float) event.getX();
        float y = (float) event.getY();
        int RawX = (int) event.getRawX();
        int RawY = (int) event.getRawY();
        float lastX = 0.0f;
        float lastY = 0.0f;
        if(draw.getPoints().size()>0){
            lastX = draw.getPoints().get(draw.getPoints().size()-1).x;
            lastY = draw.getPoints().get(draw.getPoints().size()-1).y;
            if(distance(x,y,lastX,lastY)>20){
                draw.addPoint(new Point(event.getX(), event.getY()));
            }
        }else{
            draw.addPoint(new Point(event.getX(), event.getY()));
        }

        // 表示触屏压力大小
        float pressure = event.getPressure();
        // 表示触点尺寸
        float size = event.getSize();
        // 获取绝对坐标信息

        String msg = "";

/*        msg += "事件类型" + eventType + "\n";*/
        msg += "相对坐标" + String.valueOf(x) + "," + String.valueOf(y) + "\n";
 /*       msg += "绝对坐标" + String.valueOf(RawX) + "," + String.valueOf(RawY)
                + "\n";  */
/*        msg += "触点压力" + String.valueOf(pressure) + ",";
        msg += "触点尺寸" + String.valueOf(size) + "\n";  */
        eventlable.setText(msg);
    }

    public int ProcessHistory(MotionEvent event) {
        int history = event.getHistorySize();
        for (int i = 0; i < history; i++) {
            long time = event.getHistoricalEventTime(i);
            float pressure = event.getHistoricalPressure(i);
            float x = event.getHistoricalX(i);
            float y = event.getHistoricalY(i);
            float size = event.getHistoricalSize(i);
        }

        return history;

    }

    /**********************************************************************************************************************/
    private static final String TAG = WayPointActivity.class.getName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_way_point);

        // 初始化界面和界面的点击事件
        initUIAndCallback();

        // 初始化DJI的回调函数,比如拍照录像,控制飞行的回调函数
        initDJICallback();

        // 初始化DJI的实例对象,并用上面定义的回调函数初始化下面的例子,因为设备连接变更时会调用这个函数
        // 而不必重新初始化callback,所以这里把初始化回调和初始化DJI实例分离。
        initDJIObject();

        // 初始化对 设备连接变更时 对广播的处理函数
        initBoardCastFilter();

        UIOnCreate();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(broadcastReceiver);
        super.onDestroy();
    }

    /********************************************************************************************************************************/

    TextView debuggerView;
    Button dataSendButton;
    // 初始化界面和界面的点击事件
    private void initUIAndCallback() {
        debuggerView = (TextView)findViewById(R.id.WayPointdebuggerView);
        dataSendButton = (Button)findViewById(R.id.dataSendButton);
        if (debuggerView == null) {
            toast("debug view is none");
        }
        if (dataSendButton != null) {
            dataSendButton.setOnClickListener(this);
        }else{
            print("data send button is none");
        }
    }


    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.dataSendButton){
            if(flightController != null){
                print("start send data to DJI ....");
                float[] floatData = new float[]{5,0, 0,5, -5,0, 0,-5};
                byte[] data = OurArrayByteConvertUtil.getBytes(floatData);
                sendDataToOnBoard(data);
            }else{
                print("flight controller is none");
            }
        }
    }

    /*******************************************************************************************************************************/

    DJIFlightControllerDelegate.FlightControllerReceivedDataFromExternalDeviceCallback dataReceiver = null;
    DJIBaseComponent.DJICompletionCallback dataSender = null;
    // 初始化DJI的回调函数,比如拍照录像,控制飞行的回调函数
    private void initDJICallback() {
        dataReceiver = new DJIFlightControllerDelegate.FlightControllerReceivedDataFromExternalDeviceCallback() {
            @Override
            public void onResult(byte[] bytes) {
                print("receive data :");
                print(new String(bytes));
            }
        };

        dataSender = new DataSender(this);
    }

    DJIFlightController flightController = null;
    // 初始化DJI的实例对象,并用上面定义的回调函数初始化下面的例子,因为设备连接变更时会调用这个函数
    // 而不必重新初始化callback,所以这里把初始化回调和初始化DJI实例分离。
    private void initDJIObject() {
//        DJIBaseProduct mProduct = OurDJIApplication.getProductInstance();
        DJIBaseProduct mProduct = OurDJIApplication.getProductInstance();
        if(mProduct == null  || !mProduct.isConnected()){
            print("connect failed");
            return;
        }

        if(! mProduct.getModel().equals(DJIBaseProduct.Model.UnknownAircraft)){
            if(mProduct instanceof DJIAircraft){
                DJIAircraft aircraft = (DJIAircraft)mProduct;
                flightController = aircraft.getFlightController();
                flightController.setReceiveExternalDeviceDataCallback(dataReceiver);
            }else{
                print("fail to get aircraft");
                flightController = null;
            }
        }else{
            print("unknown aircraft");
        }
    }

    /********************************************************************************************************************************/

    /** 这部分监视连接状态的功能一般不会改变 */
    private void initBoardCastFilter() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(OurDJIApplication.FLAG_CONNECTION_CHANGE);
        registerReceiver(broadcastReceiver, filter);
    }

    // 接受到连接或产品变更的广播后的处理函数
    protected BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateTitleBar();
            onProductChange();
        }
    };

    // 显示连接情况的函数 以 变更时的处理函数（重新初始化图像显示窗口）
    private void updateTitleBar() {
        boolean ret = false;
        DJIBaseProduct product = OurDJIApplication.getProductInstance();
        if(product != null){
            if(product.isConnected()){ // DJIBaseProduct
                print(OurDJIApplication.getProductInstance().getModel().toString() + " Connected");
                ret = true;
            }
            else if(product instanceof DJIAircraft){ // DJIAircraft
                DJIAircraft aircraft = (DJIAircraft)product;
                if(aircraft.getRemoteController() != null && aircraft.getRemoteController().isConnected()){
                    print("Only RC Connected");
                    ret = true;
                }
            }
        }

        if(!ret){
            print("DisConnected");
        }
    }

    private void onProductChange() {
        initDJIObject();
    }

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message message) {
            super.handleMessage(message);
            String msg = (String)message.obj;
            if(debuggerView != null){
                String str = debuggerView.getText().toString();
                if(str.length() > 1000) {
                    debuggerView.setText(str.substring(800) + "\n" + msg);
                }else{
                    debuggerView.setText(str+ "\n" +msg);
                }
                Log.i(TAG, msg);
            }else{
                toast("debug view is none");
            }
        }
    };

    public void print(final String msg){
        Message message = new Message();
        message.obj = msg;
        mHandler.sendMessage(message);
    }

    public void toast(final String msg){
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(WayPointActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void sendDataToOnBoard(byte[] data){
        if(flightController != null) {
            print("start send data to DJI ....");
            flightController.sendDataToOnboardSDKDevice(data, dataSender);//new DataSender(this)
            //print("send data :"+ Arrays.toString(data));
        }else{
            print("flight controller is none");
        }
    }
}

class DataSender implements DJIBaseComponent.DJICompletionCallback{
    WayPointActivity wayPointActivity;
    public DataSender(WayPointActivity wayPointActivity){
        this.wayPointActivity = wayPointActivity;
    }

    @Override
    public void onResult(DJIError djiError) {
        wayPointActivity.print("send data result : " + djiError);
    }
}
