package com.tju.fly.BaseWork;

import android.app.Application;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import dji.sdk.SDKManager.DJISDKManager;
import dji.sdk.base.DJIBaseComponent;
import dji.sdk.base.DJIBaseComponent.DJIComponentListener;
import dji.sdk.base.DJIBaseProduct;
import dji.sdk.base.DJIBaseProduct.DJIBaseProductListener;
import dji.sdk.base.DJIBaseProduct.DJIComponentKey;
import dji.sdk.base.DJIError;
import dji.sdk.base.DJISDKError;

/**
 * 这个Application 对于所有的mobile SDK工程都是不变的，负责
 *      1. 初始化SDK
 *      2. 监听设备的连接状况，当设备的连接状态发生改变时（收到连接或失去连接或更换了一台设备），发送一个intent广播
 *      3. 提供一个线程安全的获取当前的设备对象DJIBaseProduct的方法
 */
public class OurDJIApplication extends Application{

    private static final String TAG = OurDJIApplication.class.getName();

    public static final String FLAG_CONNECTION_CHANGE = "com_example_fpv_tutorial_connection_change";

    private static DJIBaseProduct mProduct;

    private Handler mHandler;

    boolean debug = true;

    /**
     * This function is used to get the instance of DJIBaseProduct.
     * If no product is connected, it returns null.
     */
    public static synchronized DJIBaseProduct getProductInstance() {
        if (null == mProduct) {
            mProduct = DJISDKManager.getInstance().getDJIProduct();
        }
        return mProduct;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mHandler = new Handler(Looper.getMainLooper());
        //This is used to start SDK services and initiate SDK.
        if(debug)  Log.e(TAG, "begin");
        DJISDKManager djisdkManager = DJISDKManager.getInstance();
        if(djisdkManager != null) {
            djisdkManager.initSDKManager(this, mDJISDKManagerCallback);
        }else {
            print("init dji sdk failed");
        }
    }

    /**
     * When starting SDK services, an instance of interface DJISDKManager.DJISDKManagerCallback will be used to listen to 
     * the SDK Registration result and the product changing.
     */
    private DJISDKManager.DJISDKManagerCallback mDJISDKManagerCallback = new DJISDKManager.DJISDKManagerCallback() {

        //Listens to the SDK registration result
        @Override
        public void onGetRegisteredResult(DJIError error) {
            if(debug)  Log.e(TAG, "onGetRegisteredResult");

            final DJIError result  = error;
            if(error == DJISDKError.REGISTRATION_SUCCESS) {
                if(DJISDKManager.getInstance().startConnectionToProduct()){
                    print("connection success");
                }else{
                    print("connection failed");
                }
            } else {
                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {

                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "register sdk fails, check network is available", Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(), result.getDescription(), Toast.LENGTH_LONG).show();
                    }
                });
            }
            Log.e(TAG,  error.getDescription());
        }

        //Listens to the connected product changing, including two parts, component changing or product connection changing.
        @Override
        public void onProductChanged(DJIBaseProduct oldProduct, DJIBaseProduct newProduct) {
            if(debug)  Log.e(TAG, "onProductChanged");
            mProduct = newProduct;
            if(mProduct != null) {
                mProduct.setDJIBaseProductListener(mDJIBaseProductListener);
            }

            notifyStatusChange();
        }
    };

    private DJIBaseProductListener mDJIBaseProductListener = new DJIBaseProductListener() {

        @Override
        public void onComponentChange(DJIComponentKey key, DJIBaseComponent oldComponent, DJIBaseComponent newComponent) {
            if(debug) Log.e(TAG, "onComponentChange");
            if(newComponent != null) {
                newComponent.setDJIComponentListener(mDJIComponentListener);
            }
            notifyStatusChange();
        }

        @Override
        public void onProductConnectivityChanged(boolean isConnected) {
            if(debug)  Log.e(TAG, "onProductConnectivityChanged");
            notifyStatusChange();
        }

    };

    private DJIComponentListener mDJIComponentListener = new DJIComponentListener() {

        @Override
        public void onComponentConnectivityChanged(boolean isConnected) {
            if(debug)  Log.e(TAG, "onComponentConnectivityChanged");
            notifyStatusChange();
        }

    };

    private void notifyStatusChange() {
        if(debug)  Log.e(TAG, "notifyStatusChange");
        mHandler.removeCallbacks(updateRunnable);
        mHandler.postDelayed(updateRunnable, 500);
    }

    private Runnable updateRunnable = new Runnable() {

        @Override
        public void run() {
            Intent intent = new Intent(FLAG_CONNECTION_CHANGE);
            sendBroadcast(intent);
        }
    };

    public void print(final String msg){
//        mHandler.post(new Runnable() {
//
//            @Override
//            public void run() {
//                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
//            }
//        });
//        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
        toast(msg);
    }

    public void toast(final String msg){
        mHandler.post(new Runnable() {

            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
            }
        });
    }
}
