package com.tju.fly.WayPoint;

import java.util.List;

public class Point {
	public float x = 0.0f;
	public float y = 0.0f;

	public Point(){

	}

	public Point(float xx, float yy){
		x = xx;
		y = yy;
	}
	
	public void showPoint(List<Point> p){
    	for (int i = 0; i < p.size(); i++) {
    	    System.out.println(p.get(i));
    	}
    }
}
