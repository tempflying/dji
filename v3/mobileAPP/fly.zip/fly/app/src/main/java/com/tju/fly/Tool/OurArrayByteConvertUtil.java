package com.tju.fly.Tool;

/**
 * Created by DJIPC on 2016/6/4.
 *
 */
public class OurArrayByteConvertUtil {

    public static byte[] getBytes(float[] floatArray){
        byte[] data = new byte[floatArray.length * 4];
        for(int i = 0; i < floatArray.length; i++){
            byte[] temp = OurByteConvertUtil.getBytes(floatArray[i]);
            System.arraycopy(temp, 0, data, 4 * i, 4);
        }
        return data;
    }

}
